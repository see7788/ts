module.exports = {
  baseURL: 'https://www.wxwerp.com/',
  actionURL: 'https://www.wxwerp.com/m/publish',
  dhOrigin: 'https://www.dhgate.com'
}
