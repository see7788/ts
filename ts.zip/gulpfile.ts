import { app } from "electron";
import { task, dest, watch } from "gulp";
import { createProject } from "gulp-typescript";
// import { watch } from "chokidar";
const tsProject = createProject("tsconfig.json");
task("default", () => {
  c1();
  return tsProject.src().pipe(tsProject()).js.pipe(dest("./dist"));
})

const c1 = () => watch('./src/').on(
  'all',
  (event, path) => {
    console.log(event, path);
  })